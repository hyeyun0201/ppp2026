T = 30
F = T*1.8+32
print(f"{T}℃는 화씨로 {F}℉이다")
print("{}℃는 화씨로 {}℉이다".format(T, F))

T = 0
F = T*1.8+32
print(f"{T}℃는 화씨로 {F}℉이다")
print("{}℃는 화씨로 {}℉이다".format(T, F))
